// (facultatif) – prêt à ajouter de la logique plus tard
console.log("Souffrir ton entraîneur – prêt.");
